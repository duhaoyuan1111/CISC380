/**
 * CISC 380 Algorithms Assignment 4
 * 
 * Implements dynamic programming solutions to see if a subset adds up to a
 * value.
 * 
 * @author Haoyuan Du & Shijun Yang Due Date: 11/08/20
 */

public class DynamicSum {

    private Boolean[][] L;
    private int[] ans;

    public DynamicSum() {

    }// constructor

    /**
     * Checks to see if a subset of arr adds up to exactly t with an iterative
     * solution.
     *
     * @param arr the array of integers to take subsets from.
     * @param t   the value the subset could add up to.
     * @return True, if a subset adds up to t, false otherwise.
     * 
     */
    public boolean isSum(int[] arr, int t) {
        /*
         * Running time analysis:
         * 
         * Firstly, we have two for-loops, the first one takes n times (assuming the
         * length of arr is n), and the second loop takes t times (t is the sum).
         * 
         * Secondly, we have a nest loop. The inner loop runs t times, each time it does
         * a constant work. Then, the outer loop runs n times. Thus, the total running
         * time is O(n*t).
         * 
         * Therefore, our total running time will be: n + t + (n*t) which is a tight
         * bound (by counting each part of the codes). Since this problem is a
         * NP-Complete problem just like the Knapsack problem, so n*t will be the
         * dominant term. Thus, our theta bound is \theta(n*t).
         * 
         */
        L = new Boolean[arr.length + 1][t + 1];
        for (int j = 0; j <= arr.length; j++) { // initialize the first column
            L[j][0] = true;
        }
        for (int i = 1; i <= t; i++) { // initilize the first row start at index 1
            L[0][i] = false;
        }
        for (int j = 1; j <= arr.length; j++) { // the rest of table
            for (int i = 1; i <= t; i++) {
                if (arr[j - 1] > i) { // if the current number is greater than current sum
                    L[j][i] = L[j - 1][i];
                } else { // otherwise
                    L[j][i] = L[j - 1][i] || L[j - 1][i - arr[j - 1]];
                }
            }

        }

        return L[arr.length][t];
    }// isSum

    /**
     * Checks to see if a subset of arr adds up to exactly t with a memoizied
     * solution.
     *
     * @param arr the array of integers to take subsets from.
     * @param t   the value the subset could add up to.
     * @return True, if a subset adds up to t, false otherwise.
     * 
     */
    public boolean isSumMem(int[] arr, int t) {
        // The running time analysis is below.
        L = new Boolean[arr.length + 1][t + 1];

        return isSumMem(arr, t, arr.length, t);

    }// isSumMem

    /**
     * Private method of isSumMem(int[] arr, int t)
     * 
     * @param arr the array of integers to take subsets from.
     * @param t   the value the subset could add up to.
     * @param j   arr.length
     * @param i   t
     * @return True, if a subset adds up to t, false otherwise.
     */
    private boolean isSumMem(int[] arr, int t, int j, int i) {
        /*
         * Running time analysis:
         * 
         * Firstly, we have two base cases and one memoization which are constant time.
         * 
         * Secondly, the recursion part has one if-else statement, handling two
         * situations: 1. if the current value is greater than the current sum, then
         * recurse on the position above. 2. otherwise, recurse on the position at
         * diagonal (at [j-1, i-arr[j - 1]]) and the position above. Since each call to
         * subproblem takes constant time, we call it once from the main routine, and at
         * most twice every time we fill the table. Thus, there are (n+1)(t+1) entries,
         * so the total number of calls is at most 2(n+1)(t+1)+1 so that the time is
         * \theta(n*t).
         * 
         * 
         */
        Boolean result = null;

        if (j == 0 && i >= 1) { // base case
            return false;
        }
        if (i == 0) {
            return true;
        }
        if (L[j][i] != null) { // memoization
            return L[j][i];
        }
        // recursion
        if (arr[j - 1] > i) { // recurse on the position above it
            result = isSumMem(arr, t, j - 1, i);
        } else { // recurse on the position at diagonal and the position above it
            result = isSumMem(arr, t, j - 1, i) || isSumMem(arr, t, j - 1, i - arr[j - 1]);
        }
        L[j][i] = result;
        return result;
    }

    /**
     * Recovers the subset of arr that adds up to t, if it exists.
     *
     * @param arr the array of integers to take subsets from.
     * @param t   the value the subset could add up to.
     * @return a subset of arr that adds up to t, null otherwise.
     * 
     */
    public int[] getSubset(int[] arr, int t) {
        /*
         * Running time analysis:
         * 
         * Firstly, the initializations and if statement takes constant time. Also, We
         * call isSum(arr, t) method to fill the table which is O(n*t).
         * 
         * Secondly, the first while loop takes n time. Because each while loop the j
         * will decrease by 1 and j is the length of arr which is n. Then, the second
         * while loop also takes n time. Because they are almost same except we save the
         * exact number into the array (save number takes constant time).
         * 
         * Therefore, our total running time will be: n*t + n + n + c. It's \theta(n*t).
         * 
         * So, this recovery code didn't take longer in terms of O notation than the
         * time to ��fill the table��.
         * 
         * 
         */
        int count = 0;
        int i = t;
        int j = arr.length;
        Boolean valid = isSum(arr, t);

        if (valid == false) { // not valid
            return null;
        }

        while (j > 0 || i > 0) { // to get how many elements will be in our int[]
            if (L[j][i] == L[j - 1][i]) { // go up
                j--;
            } else if (L[j][i] != L[j - 1][i] && L[j][i] == L[j - 1][i - arr[j - 1]]) { // go diagonal, count++
                count++;
                i = i - arr[j - 1];
                j--;
            }
        }
        ans = new int[count]; // declare size of int[]
        int k = count - 1;
        i = t; // reset
        j = arr.length;
        while (j > 0 || i > 0) { // put each exact correct component into our int[]
            if (L[j][i] == L[j - 1][i]) { // go up
                j--;
            } else if (L[j][i] != L[j - 1][i] && L[j][i] == L[j - 1][i - arr[j - 1]]) { // go diagonal, save the
                                                                                        // component
                ans[k] = arr[j - 1];
                k--;
                i = i - arr[j - 1];
                j--;
            }
        }
        return ans;
    }// getSubset

}// class