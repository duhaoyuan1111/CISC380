/**
 * CISC 380 Algorithms Assignment 4 EXTRA CREDIT
 * 
 * Implements a dynamic programming solution to find the length of the longest
 * palindromic subsequence.
 * 
 * @author Haoyuan Du & Shijun Yang Due Date: 11/08/20
 */

public class PalindromicSequence {

    private static int[][] L;

    public PalindromicSequence() {

    }

    /**
     * Implements a dynamic programming solution to find the length of the longest
     * Palindromic subsequence of the given string.
     * 
     * 
     * @param x the string that may contain a palindromic subsequence
     * @return the length of the longest palindromic subsequence, or 0 if there is
     *         none.
     */
    public static int getLengthLongestPalindrome(String x) {
        // this iteration method big-o is O(n^2), assuming the length of x is n.
        if (x.length() == 0) { // if string is empty
            return 0;
        }
        L = new int[x.length()][x.length()];

        L[0][0] = 1; // initialize [0][0] to 1
        for (int i = 1; i < x.length(); i++) { // fill the diagonal
            L[i][i] = 1;
            L[i][i - 1] = 0;
        }
        for (int width = 1; width <= x.length(); width++) { // go down the diagonal like the Chain Matrix problem,
                                                            // the longest length is saved at top-right corner in the
                                                            // table
            for (int j = 0; j < x.length() - width; j++) {
                int i = j + width;
                if (x.charAt(i) == x.charAt(j)) {
                    L[j][i] = L[j + 1][i - 1] + 2; // if they are same, plus 2 to the value of L[j + 1][i - 1]
                } else {
                    L[j][i] = Integer.max(L[j + 1][i], L[j][i - 1]); // if not same, take the maximum value either from
                                                                     // L[j + 1][i] OR L[j][i - 1]
                }
            }
        }
        return L[0][x.length() - 1];

    }// longestPalindrome

    /**
     * Implements a dynamic programming solution to return the longest palindromic
     * subsequence of the given string
     * 
     * @param x the string that may contain a palindromic subsequence
     * @return the string of the longest palindrome, or null if there is none
     */
    public static String getLongestPalindrome(String x) {
        // This recovery method is O(n), assuming the length of x is n
        StringBuilder right = new StringBuilder();
        int number = getLengthLongestPalindrome(x); // fill the table by calling getLengthLongestPalindrome()
        int i = x.length() - 1;
        int j = 0;
        StringBuilder left = new StringBuilder();
        if (x.length() == 0) { // if string is empty
            return "";
        }
        if (x.length() == 1) { // if string is a single character
            return x;
        }

        while (i > j) { // start from the top-right corner
            if (L[j][i] != L[j][i - 1] && L[j][i - 1] == L[j + 1][i]) { // append this character, go to the diagonal
                                                                        // spot
                left.append(x.charAt(i));
                i--;
                j++;
            } else if (L[j][i] == L[j][i - 1]) { // go left, no appending
                i--;
            } else if (L[j][i] == L[j + 1][i]) { // go down, no appending
                j++;
            }
        }

        if (i == j) { // if reach the diagonal, append the last character
            left.append(x.charAt(i));
        }
        if (number % 2 == 0) { // even
            right.append(left.reverse());
            left.reverse();

        } else { // odd
            String temp;
            temp = left.reverse().toString();
            temp = temp.substring(1, temp.length());
            right.append(temp);
            left.reverse();
        }
        return left.append(right).toString();
    }

}// class