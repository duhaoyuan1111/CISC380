/**
 * CISC 380 Algorithms Assignment 3
 *
 * Implements a dynamic programming solution to the Interleaving Strings
 * problem.
 * 
 * @author Haoyuan Du, Aaron Marshall Due Date: 10/25/20
 */

public class Interleaver {

    private StringBuilder ans;
    private Boolean[][] table;

    public Interleaver() {

    }// constructor

    /**
     * Finds if the two strings x and y are an interleaving of string z
     * 
     * The string Z is an interleaving of X and Y if it can be obtained by
     * interleaving the characters in X and Y in a way that maintains the
     * left-to-right order of the c in X and Y:
     * 
     * @param x the first string that composes an interleaving
     * @param y the second string that composes an interleaving
     * @param z the string to check for an interleaving
     * @return True, if the string z is an interleaving of x and y. False otherwise.
     * 
     */
    public Boolean isInterleaved(String x, String y, String z) {

        table = new Boolean[y.length() + 1][x.length() + 1]; // create the 2D table and call the private method below
        table[0][0] = true;
        return isInterleaved(x, y, z, table, x.length(), y.length());

    }// isInterleaved

    /**
     * Finds if the two strings x and y are an interleaving of string z
     * 
     * The string Z is an interleaving of X and Y if it can be obtained by
     * interleaving the characters in X and Y in a way that maintains the
     * left-to-right order of the c in X and Y:
     * 
     * @param x the first string that composes an interleaving
     * @param y the second string that composes an interleaving
     * @param z the string to check for an interleaving
     * @param L the table
     * @param i length of x
     * @param j length of y
     * @return
     */
    private Boolean isInterleaved(String x, String y, String z, Boolean[][] L, int i, int j) {
        /*
         * Running time analysis:
         * 
         * Firstly, assuming the length of x is n, the length of y is m.
         * 
         * Secondly, there are two base cases. If it reaches the left-top, return true.
         * If we can find the answer in the table, we return that value (memoization).
         * 
         * Thirdly, the recursion part has three pairs of if statements, handling three
         * situations: 1. the left most column. 2. the top most row. 3. the rest of
         * table. Since each call to subproblem takes constant time, we call it once
         * from the main routine, and at most twice every time we fill the table. Thus,
         * there are (m+1)(n+1) entries, so the total number of calls is at most
         * 2(m+1)(n+1)+1 so that the time is theta(m*n).
         * 
         */

        Boolean result = null;
        if (i == 0 && j == 0) { // base case: if reach the top left, return true. Because both strings are empty
            return true;
        }
        if (L[j][i] != null) { // memoization
            return L[j][i];
        }
        if (i > 0 && j == 0) { // if reach the left most column, recurse on (i-1, j)
            if (z.charAt(j + i - 1) == x.charAt(i - 1)) {
                result = isInterleaved(x, y, z, L, i - 1, j);
            } else {
                result = false;
            }
        } else if (i == 0 && j > 0) { // if reach the top row, recurse on (i, j-1)
            if (z.charAt(j + i - 1) == y.charAt(j - 1)) {
                result = isInterleaved(x, y, z, L, i, j - 1);
            } else {
                result = false;
            }
        } else {
            if (z.charAt(j + i - 1) == x.charAt(i - 1) && z.charAt(j + i - 1) != y.charAt(j - 1)) {
                // if z[i+j] equals x[i] but not y[j], recurse on the left spot
                result = isInterleaved(x, y, z, L, i - 1, j);
            } else if (z.charAt(j + i - 1) != x.charAt(i - 1) && z.charAt(j + i - 1) == y.charAt(j - 1)) {
                // z[i+j]==y[j] but z[i+j]!=x[i], recurse on the spot above
                result = isInterleaved(x, y, z, L, i, j - 1);
            } else if (z.charAt(j + i - 1) == x.charAt(i - 1) && z.charAt(j + i - 1) == y.charAt(j - 1)) {
                // if they both equals, recurse on left as well as above, then OR the answer
                result = isInterleaved(x, y, z, L, i, j - 1) || isInterleaved(x, y, z, L, i - 1, j);
            } else if (z.charAt(j + i - 1) != x.charAt(i - 1) && z.charAt(j + i - 1) != y.charAt(j - 1)) {
                // if both are not equals, return false
                result = false;
            }
        }

        table[j][i] = result;
        return result;
    }

    /**
     * Returns a string representation of the solution of the interleaved string
     * problem.
     * 
     * The return value is a string whose length is equal to z. All characters in z
     * are replaced by character "x" if they come from the string "x", and all
     * characters in z are replaced by the character "y" if they come from the
     * string y.
     * 
     * For example, on an input of x = "ab", y = "cd", and z = "abcd", then the
     * output shall be the string "xxyy".
     * 
     * @param x the first string that composes an interleaving
     * @param y the second string that composes an interleaving
     * @param z the string to check for an interleaving
     * @return A string representation of the solution
     */
    public String getSolution(String x, String y, String z) {
        String temp;
        StringBuilder answer = new StringBuilder();
        isInterleaved(x, y, z); // call the method to fill the table
        ans = new StringBuilder();
        temp = getSolution(x.length(), y.length(), table); // call private method
        answer.append(temp);

        return answer.reverse().toString(); // since we recurse from the down right corner, we need to reverse the
                                            // string
    }

    /**
     * !Private function of getSolution()!
     * 
     * Returns a string representation of the solution of the interleaved string
     * problem.
     * 
     * The return value is a string whose length is equal to z. All characters in z
     * are replaced by character "x" if they come from the string "x", and all
     * characters in z are replaced by the character "y" if they come from the
     * string y.
     * 
     * For example, on an input of x = "ab", y = "cd", and z = "abcd", then the
     * output shall be the string "xxyy".
     * 
     * @param i length of x string
     * @param j length of y string
     * @param L the memoization table
     * @return
     */
    private String getSolution(int i, int j, Boolean[][] L) {
        // this method is O(m+n) which is less than filling the table which takes O(mn)
        if (i == 0 && j == 0) { // base case: if reach top left, return null
            return null;
        } else if (j >= 1 && L[j][i] == L[j - 1][i]) { // if the current spot is equal to the one above, then it means
                                                       // this character comes from string Y
            ans.append("y");
            getSolution(i, j - 1, L);
        } else if (i >= 1 && L[j][i] == L[j][i - 1]) { // if the current spot is equal to the left one, then it means
                                                       // this character comes from string X
            ans.append("x");
            getSolution(i - 1, j, L);
        }
        return ans.toString();
    }

}// class